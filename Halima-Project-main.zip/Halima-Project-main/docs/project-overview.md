# AI-Powered Memory Assistant for Alzheimer's Patients

**Course:** CS-609
**Supervisor:** Mam Wajeeha Azmat
**Submitted by:** Halima Awais (AG#2022-AG-7729)
**Department:** Computer Science, University of Agriculture, Faisalabad

---

## What the Project Is About

A cross-platform mobile application — supported by a caregiver dashboard and cloud services — that helps Alzheimer's patients cope with progressive memory loss. The system has two roles: **Patient** and **Caregiver**.

The core idea is to combine on-device AI with simple, accessible UX so that patients can:

- Recognize familiar people through the camera (face recognition + voice announcement of names/relations).
- Receive context-aware voice reminders for medication, appointments, and daily routines.
- Trigger an Emergency SOS and keep a memory journal.

Caregivers manage patients' reminders, enroll familiar faces, and monitor activity from their own dashboard.

The app is privacy-conscious (face embeddings stored locally rather than raw images), accessibility-focused (large buttons, readable text, voice interaction), and designed to keep working with limited or no internet.

**Out of scope:** clinical diagnosis, complex medical decision-making, real-time emergency medical response.

---

## Objectives

- Implement lightweight on-device face recognition with model quantization for performance.
- Provide context-aware voice reminders tied to recognized identities and schedules.
- Implement caregiver management features (profile edits, schedule assignment).
- Ensure data security and offline support for critical features.
- Validate the system with basic usability testing and gather user feedback.

---

## Deliverables

### 1. Documentation Deliverables

| # | Deliverable | Source / Phase |
|---|-------------|----------------|
| 1 | Software Requirements Specification (SRS) | RAD — Requirement Planning |
| 2 | UI Mockups / Prototype | RAD — User Design |
| 3 | System Architecture Diagram (Figure 1) | Methodology |
| 4 | Use Case Diagram (Figure 2) | Methodology |
| 5 | Data Flow Diagram (Figure 3) | Methodology |
| 6 | Gantt Chart / 12-week project schedule (Figure 4) | Timeline |
| 7 | Test Report | RAD — Testing |
| 8 | Final FYP Report | RAD — Deployment |

### 2. Software Deliverables

| # | Deliverable | Notes |
|---|-------------|-------|
| 1 | Cross-platform mobile app (Flutter) | Patient + Caregiver roles |
| 2 | On-device face recognition engine | TensorFlow Lite, MobileFaceNet |
| 3 | Caregiver web/app dashboard | Reminder + face enrollment management |
| 4 | Cloud-backed persistence | Firebase Auth + Firestore |
| 5 | Voice reminder & TTS subsystem | Google Text-to-Speech |
| 6 | Deployed working app | Final RAD phase output |

### 3. Functional Modules to Deliver

- **FR01 — User Authentication:** email/password login, role-based (Patient / Caregiver).
- **FR02 — User Registration:** account creation with name, email, password, role.
- **FR03 — Profile Management:** view/update profile, change password.
- **FR04 — Face Enrollment:** capture, store, and delete enrolled faces.
- **FR05 — Face Detection & Recognition:** detect via camera, match against enrolled set, announce name via voice.
- **FR06 — Reminder Management:** add/edit/delete reminders, voice alerts, offline support.
- **FR07 — Caregiver Dashboard:** patient overview, reminders view, basic activity info.
- **FR08 — Emergency SOS:** SOS button on patient screen with alert (caregiver notification in future phase).
- **FR09 — Memory Journal:** patients can write, store, and review memory notes.

### 4. Non-Functional Targets

- **Usability (High):** simple UI, large buttons, voice-based interaction.
- **Performance (High/Med):** face recognition within 2 seconds; multi-reminder handling without delay.
- **Security (High):** encrypted storage, restricted access to patient data.
- **Reliability (High/Med):** 24/7 availability; basic functionality during internet loss.
- **Compatibility (Med/Low):** runs on low-end Android devices; maintainable for future updates.

---

## Methodology

**Process Model:** Rapid Application Development (RAD) — chosen for iterative feedback cycles, quick prototyping, and parallel development of AI modules and frontend.

**RAD Phases**

| Phase | Activities | Deliverable |
|-------|-----------|-------------|
| Requirement Planning | Gather requirements | SRS |
| User Design | Prototype & feedback | UI Mockups |
| Construction | Coding modules | Working system |
| Testing | System testing | Test report |
| Deployment | Final submission | Deployed app |

---

## Tools & Technologies

| Module | Technology | Purpose |
|--------|-----------|---------|
| UI | Flutter | Mobile frontend |
| Authentication | Firebase Auth | Secure access |
| Face Recognition | TensorFlow Lite | On-device AI inference |
| Database | Firestore | Cloud storage |
| Voice | Google TTS | Audio output |
| Prototyping | Figma | UI/UX design |
| Version Control | GitHub | Source management |
| Backend (planned) | Python (Flask/Django) | Optional backend |
| IDE | Android Studio | Development |

---

## Hardware / Software Requirements

**Hardware (minimum):** 1.6 GHz CPU, 2 GB RAM, 1 GB storage, 5 MP camera.
**Hardware (recommended):** 2.0 GHz+ CPU, 4 GB RAM.
**Software:** Android 8.0+, Flutter, Firebase, TensorFlow Lite, Google TTS.

---

## Implementation Status (per report — 40%)

| Module | Status | Description |
|--------|--------|-------------|
| Frontend UI | Completed | Basic Flutter screens |
| Authentication | Completed | Firebase login/signup |
| Face Recognition | Partial | Demo integration |
| Reminder System | Partial | Voice reminders |

---

## Future Work (from the report)

- Collect a small evaluation dataset.
- Conduct user studies with caregivers and patients.
- Optimize ML models for on-device inference.
- Improve accessibility (multi-language TTS, larger interface components).
- Wire SOS to actually notify caregivers.
