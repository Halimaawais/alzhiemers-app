// lib/screens/sos_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SosScreen extends StatefulWidget {
  const SosScreen({super.key});

  @override
  State<SosScreen> createState() => _SosScreenState();
}

class _SosScreenState extends State<SosScreen> with SingleTickerProviderStateMixin {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String uid = FirebaseAuth.instance.currentUser!.uid;

  bool _isSending = false;
  bool _sosSent = false;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _sendSOS() async {
    setState(() => _isSending = true);

    try {
      await _firestore.collection('sos_events').add({
        'patientId': uid,
        'timestamp': FieldValue.serverTimestamp(),
        'status': 'active',
        'message': 'Patient needs immediate help!',
      });

      setState(() {
        _isSending = false;
        _sosSent = true;
      });

      _pulseController.stop();

    } catch (e) {
      setState(() => _isSending = false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not send SOS: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _resetSOS() {
    setState(() => _sosSent = false);
    _pulseController.repeat(reverse: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _sosSent ? Colors.green.shade50 : Colors.red.shade50,
      appBar: AppBar(
        backgroundColor: _sosSent ? Colors.green.shade700 : Colors.red.shade700,
        foregroundColor: Colors.white,
        title: const Text('Emergency SOS'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _sosSent
              // ── After SOS sent ──────────────────────────────────────────
              ? Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.check_circle, color: Colors.green, size: 100),
                    const SizedBox(height: 24),
                    const Text(
                      'Help is on the way!',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Your caregiver has been notified.\nPlease stay calm and stay where you are.',
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.green.shade800,
                        height: 1.6,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 40),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.green.shade100,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Column(
                        children: [
                          Text('✅  Stay where you are', style: TextStyle(fontSize: 16, height: 2)),
                          Text('✅  Stay calm and breathe slowly', style: TextStyle(fontSize: 16, height: 2)),
                          Text('✅  Help is coming soon', style: TextStyle(fontSize: 16, height: 2)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 40),
                    TextButton(
                      onPressed: _resetSOS,
                      child: const Text('Send Another Alert', style: TextStyle(fontSize: 16)),
                    ),
                  ],
                )
              // ── Before SOS sent ─────────────────────────────────────────
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.warning_amber_rounded, color: Colors.red, size: 60),
                    const SizedBox(height: 16),
                    const Text(
                      'Need Help?',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Press the button below to alert\nyour caregiver immediately',
                      style: TextStyle(fontSize: 16, color: Colors.red.shade700, height: 1.5),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 60),

                    // Pulsing SOS button
                    AnimatedBuilder(
                      animation: _pulseAnimation,
                      builder: (context, child) {
                        return Transform.scale(
                          scale: _pulseAnimation.value,
                          child: child,
                        );
                      },
                      child: GestureDetector(
                        onTap: _isSending ? null : () async {
                          final confirm = await showDialog<bool>(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: const Row(
                                children: [
                                  Icon(Icons.warning, color: Colors.red),
                                  SizedBox(width: 8),
                                  Text('Send Emergency Alert?'),
                                ],
                              ),
                              content: const Text(
                                'This will immediately notify your caregiver that you need help.',
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context, false),
                                  child: const Text('Cancel'),
                                ),
                                ElevatedButton(
                                  onPressed: () => Navigator.pop(context, true),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.red,
                                    foregroundColor: Colors.white,
                                  ),
                                  child: const Text('Yes, Send Alert!'),
                                ),
                              ],
                            ),
                          );
                          if (confirm == true) _sendSOS();
                        },
                        child: Container(
                          width: 200,
                          height: 200,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.red.shade600,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.red.shade300,
                                blurRadius: 30,
                                spreadRadius: 10,
                              ),
                            ],
                          ),
                          child: _isSending
                              ? const Center(
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 4,
                                  ),
                                )
                              : const Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.sos, color: Colors.white, size: 80),
                                    SizedBox(height: 8),
                                    Text(
                                      'PRESS FOR\nHELP',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18,
                                        height: 1.3,
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 40),
                    Text(
                      'Only press if you feel unsafe or confused',
                      style: TextStyle(fontSize: 14, color: Colors.red.shade400),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}