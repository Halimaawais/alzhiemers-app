// lib/screens/face_enrollment_screen.dart
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image/image.dart' as img;
import 'dart:io';
import '../face_embedding_service.dart';

class FaceEnrollmentScreenLocal extends StatefulWidget {
  final String patientId;
  final String patientName;

  const FaceEnrollmentScreenLocal({
    super.key,
    required this.patientId,
    required this.patientName,
  });

  @override
  State<FaceEnrollmentScreenLocal> createState() =>
      _FaceEnrollmentScreenLocalState();
}

class _FaceEnrollmentScreenLocalState
    extends State<FaceEnrollmentScreenLocal> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _caregiverId = FirebaseAuth.instance.currentUser!.uid;
  final FaceEmbeddingService _embeddingService = FaceEmbeddingService();
  final FaceDetector _faceDetector = FaceDetector(
    options: FaceDetectorOptions(),
  );

  final _nameController = TextEditingController();
  final _relationController = TextEditingController();
  File? _selectedImage;
  bool _isUploading = false;
  bool _modelLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadModel();
  }

  Future<void> _loadModel() async {
    await _embeddingService.loadModel();
    setState(() => _modelLoaded = _embeddingService.isLoaded);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _relationController.dispose();
    _faceDetector.close();
    _embeddingService.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: source,
      maxWidth: 800,
      maxHeight: 800,
      imageQuality: 85,
    );
    if (pickedFile != null) {
      setState(() => _selectedImage = File(pickedFile.path));
    }
  }

  Future<String> _saveImageLocally(File imageFile) async {
    final directory = await getApplicationDocumentsDirectory();
    final facesDir =
        Directory('${directory.path}/faces/${widget.patientId}');
    if (!await facesDir.exists()) {
      await facesDir.create(recursive: true);
    }
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final localPath = '${facesDir.path}/$timestamp.jpg';
    final savedImage = await imageFile.copy(localPath);
    return savedImage.path;
  }

  Future<void> _enrollFace() async {
    if (_selectedImage == null) {
      _showSnack('Please select a photo', Colors.orange);
      return;
    }
    if (_nameController.text.trim().isEmpty) {
      _showSnack('Please enter a name', Colors.orange);
      return;
    }

    setState(() => _isUploading = true);

    try {
      // ── Step 1: Detect face in image ───────────────────────────────────
      final inputImage = InputImage.fromFilePath(_selectedImage!.path);
      final faces = await _faceDetector.processImage(inputImage);

      if (faces.isEmpty) {
        _showSnack(
            'No face detected! Please use a clear front-facing photo.',
            Colors.orange);
        setState(() => _isUploading = false);
        return;
      }

      // ── Step 2: Crop face, then generate TFLite embedding ──────────────
      // The recognition path embeds a cropped face, so enrollment must too —
      // otherwise the enrolled vector encodes the whole scene, not the face.
      final decoded = img.decodeImage(await _selectedImage!.readAsBytes());
      if (decoded == null) {
        _showSnack('Could not read image file.', Colors.red);
        setState(() => _isUploading = false);
        return;
      }
      final croppedFace = FaceEmbeddingService.cropFace(decoded, faces.first);
      if (croppedFace == null) {
        _showSnack('Could not crop face from image.', Colors.red);
        setState(() => _isUploading = false);
        return;
      }
      final embedding =
          await _embeddingService.getEmbeddingFromImage(croppedFace);
      print('Embedding length: ${embedding.length}');

      // ── Step 3: Save image locally ─────────────────────────────────────
      final localPath = await _saveImageLocally(_selectedImage!);

      // ── Step 4: Save embedding to Hive ─────────────────────────────────
      final box = Hive.box('facesBox');
      final hiveKey =
          '${widget.patientId}_${DateTime.now().millisecondsSinceEpoch}';
      await box.put(hiveKey, {
        'name': _nameController.text.trim(),
        'relationship': _relationController.text.trim(),
        'embedding': embedding,
        'patientId': widget.patientId,
        'localImagePath': localPath,
      });
      print('✅ Saved to Hive with key: $hiveKey');

      // ── Step 5: Save metadata to Firestore ─────────────────────────────
      await _firestore.collection('enrolled_faces').add({
        'patientId': widget.patientId,
        'caregiverId': _caregiverId,
        'name': _nameController.text.trim(),
        'relationship': _relationController.text.trim(),
        'localImagePath': localPath,
        'hiveKey': hiveKey,
        'enrolledAt': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      _showSnack(
          '${_nameController.text} enrolled successfully! ✅', Colors.green);

      setState(() {
        _selectedImage = null;
        _nameController.clear();
        _relationController.clear();
      });
    } catch (e) {
      if (!mounted) return;
      _showSnack('Error enrolling face: $e', Colors.red);
    } finally {
      setState(() => _isUploading = false);
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: color),
    );
  }

  void _showImageSourceDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Image Source'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Colors.blue),
              title: const Text('Camera'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading:
                  const Icon(Icons.photo_library, color: Colors.green),
              title: const Text('Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Enroll New Face'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Model status
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _modelLoaded
                    ? Colors.green.shade50
                    : Colors.orange.shade50,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: _modelLoaded
                        ? Colors.green.shade300
                        : Colors.orange.shade300),
              ),
              child: Row(
                children: [
                  Icon(
                    _modelLoaded ? Icons.check_circle : Icons.hourglass_empty,
                    color:
                        _modelLoaded ? Colors.green : Colors.orange,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _modelLoaded
                        ? 'AI Model Ready (TFLite MobileFaceNet)'
                        : 'Loading AI Model...',
                    style: TextStyle(
                      color: _modelLoaded
                          ? Colors.green.shade800
                          : Colors.orange.shade800,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Patient info card
            Card(
              color: Colors.teal.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    const CircleAvatar(
                      backgroundColor: Colors.teal,
                      child: Icon(Icons.person, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Enrolling for patient:',
                            style:
                                TextStyle(fontSize: 12, color: Colors.grey)),
                        Text(widget.patientName,
                            style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Image picker
            GestureDetector(
              onTap: _showImageSourceDialog,
              child: Container(
                height: 220,
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(16),
                  border:
                      Border.all(color: Colors.grey.shade300, width: 2),
                ),
                child: _selectedImage != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Image.file(_selectedImage!,
                            fit: BoxFit.cover),
                      )
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add_a_photo,
                              size: 60, color: Colors.grey.shade400),
                          const SizedBox(height: 12),
                          Text('Tap to add photo',
                              style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.grey.shade600)),
                          const SizedBox(height: 4),
                          Text('Use a clear front-facing photo',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey.shade500)),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 20),

            // Name field
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Person\'s Name *',
                hintText: 'e.g., Ali',
                prefixIcon: const Icon(Icons.person_outline),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.grey.shade50,
              ),
            ),
            const SizedBox(height: 16),

            // Relationship field
            TextField(
              controller: _relationController,
              decoration: InputDecoration(
                labelText: 'Relationship (Optional)',
                hintText: 'e.g., Son, Doctor, Friend',
                prefixIcon: const Icon(Icons.family_restroom),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.grey.shade50,
              ),
            ),
            const SizedBox(height: 24),

            // Enroll button
            SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: _isUploading ? null : _enrollFace,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                child: _isUploading
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                    Colors.white)),
                          ),
                          SizedBox(width: 12),
                          Text('Enrolling... Please wait'),
                        ],
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.face_retouching_natural),
                          SizedBox(width: 8),
                          Text('Enroll Face',
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}