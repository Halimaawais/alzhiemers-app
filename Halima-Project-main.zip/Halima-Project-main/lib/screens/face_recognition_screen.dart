// lib/screens/face_recognition_screen.dart
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:image/image.dart' as img;
import '../face_embedding_service.dart';

class FaceRecognitionScreen extends StatefulWidget {
  const FaceRecognitionScreen({super.key});

  @override
  State<FaceRecognitionScreen> createState() => _FaceRecognitionScreenState();
}

class _FaceRecognitionScreenState extends State<FaceRecognitionScreen> {
  CameraController? _cameraController;
  final FaceDetector _faceDetector = FaceDetector(
    options: FaceDetectorOptions(
      enableContours: false,
      enableClassification: false,
      minFaceSize: 0.1,
    ),
  );
  final FlutterTts _flutterTts = FlutterTts();
  final FaceEmbeddingService _embeddingService = FaceEmbeddingService();

  bool _isDetecting = false;
  bool _isCameraInitialized = false;
  bool _modelLoaded = false;
  Timer? _detectionTimer;

  String _statusMessage = 'Loading AI model...';
  String _recognizedName = '';
  String _recognizedRelation = '';
  double _lastScore = 0.0;

  @override
  void initState() {
    super.initState();
    _initAll();
  }

  Future<void> _initAll() async {
    await _initTts();
    await _loadModel();
    await _initCamera();
  }

  Future<void> _initTts() async {
    await _flutterTts.setLanguage('en-US');
    await _flutterTts.setSpeechRate(0.5);
    await _flutterTts.setVolume(1.0);
    await _flutterTts.setPitch(1.0);
  }

  Future<void> _loadModel() async {
    await _embeddingService.loadModel();
    setState(() {
      _modelLoaded = _embeddingService.isLoaded;
      _statusMessage = _modelLoaded
          ? 'Point camera at a face'
          : 'Model failed to load';
    });
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() => _statusMessage = 'No camera found');
        return;
      }

      // Prefer front camera
      final camera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );

      _cameraController = CameraController(
        camera,
        ResolutionPreset.medium,
        enableAudio: false,
      );

      await _cameraController!.initialize();
      if (!mounted) return;

      setState(() => _isCameraInitialized = true);
      _startAutoScan();
    } catch (e) {
      setState(() => _statusMessage = 'Camera error: $e');
    }
  }

  void _startAutoScan() {
    // Scan every 2 seconds automatically
    _detectionTimer =
        Timer.periodic(const Duration(seconds: 2), (timer) {
      if (!_isDetecting && _isCameraInitialized) {
        _detectAndRecognize();
      }
    });
  }

  Future<void> _detectAndRecognize() async {
    if (_cameraController == null ||
        !_cameraController!.value.isInitialized) return;

    _isDetecting = true;
    setState(() => _statusMessage = 'Scanning...');

    try {
      // Step 1: Take photo
      final photo = await _cameraController!.takePicture();

      // Step 2: Detect face with ML Kit
      final inputImage = InputImage.fromFilePath(photo.path);
      final faces = await _faceDetector.processImage(inputImage);

      if (faces.isEmpty) {
        setState(() {
          _statusMessage = 'No face detected. Point camera at a face.';
          _recognizedName = '';
          _recognizedRelation = '';
        });
        _isDetecting = false;
        return;
      }

      setState(() => _statusMessage = 'Face detected! Identifying...');

      // Step 3: Crop face from image (in-memory, no JPEG round-trip)
      final decoded = img.decodeImage(await File(photo.path).readAsBytes());
      if (decoded == null) {
        _isDetecting = false;
        return;
      }
      final croppedFace =
          FaceEmbeddingService.cropFace(decoded, faces.first);
      if (croppedFace == null) {
        _isDetecting = false;
        return;
      }

      // Step 4: Generate TFLite embedding
      final embedding =
          await _embeddingService.getEmbeddingFromImage(croppedFace);

      // Step 5: Find best match in Hive
      final match = _findBestMatch(embedding);

      if (match != null) {
        final name = match['name'] ?? 'Unknown';
        final relation = match['relationship'] ?? '';
        final score = match['score'] as double;

        setState(() {
          _recognizedName = name;
          _recognizedRelation = relation;
          _lastScore = score;
          _statusMessage = 'Person identified! ✅';
        });

        // Speak the name
        String speech = 'This is $name';
        if (relation.isNotEmpty) speech += ', $relation';
        await _flutterTts.speak(speech);
      } else {
        setState(() {
          _statusMessage = 'Face not recognized';
          _recognizedName = '';
          _recognizedRelation = '';
          _lastScore = 0.0;
        });
      }
    } catch (e) {
      setState(() => _statusMessage = 'Error: $e');
      print('Recognition error: $e');
    }

    _isDetecting = false;
  }

  // Compare embedding against all stored faces in Hive
  Map<String, dynamic>? _findBestMatch(List<double> embedding) {
    final box = Hive.box('facesBox');
    if (box.isEmpty) {
      setState(() => _statusMessage = 'No faces enrolled yet!');
      return null;
    }

    double bestScore = -1.0;
    Map<String, dynamic>? bestMatch;

    for (final key in box.keys) {
      try {
        final stored = box.get(key);
        if (stored == null) continue;

        final storedMap = Map<String, dynamic>.from(stored);
        final storedEmbedding = List<double>.from(storedMap['embedding']);

        final score = _cosineSimilarity(embedding, storedEmbedding);
        print('Comparing with ${storedMap['name']}: score = $score');

        if (score > bestScore) {
          bestScore = score;
          bestMatch = {...storedMap, 'score': score};
        }
      } catch (e) {
        print('Error comparing face: $e');
        continue;
      }
    }

    print('Best score: $bestScore');
    // 0.65 threshold (slightly lower than 0.7 for better recall)
    return bestScore >= 0.65 ? bestMatch : null;
  }

  // Cosine similarity between two embedding vectors
  double _cosineSimilarity(List<double> a, List<double> b) {
    if (a.length != b.length) return 0.0;
    double dot = 0.0, normA = 0.0, normB = 0.0;
    for (int i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    if (normA == 0.0 || normB == 0.0) return 0.0;
    return dot / (sqrt(normA) * sqrt(normB));
  }

  @override
  void dispose() {
    _detectionTimer?.cancel();
    _cameraController?.dispose();
    _faceDetector.close();
    _flutterTts.stop();
    _embeddingService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Face Recognition'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          // Camera preview
          if (_isCameraInitialized && _cameraController != null)
            Positioned.fill(
              child: CameraPreview(_cameraController!),
            )
          else
            const Center(
              child: CircularProgressIndicator(color: Colors.white),
            ),

          // Status bar at top
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.7),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(
                    _modelLoaded
                        ? Icons.psychology
                        : Icons.warning_amber,
                    color:
                        _modelLoaded ? Colors.green : Colors.orange,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _statusMessage,
                      style: const TextStyle(
                          color: Colors.white, fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Recognized person card at bottom
          if (_recognizedName.isNotEmpty)
            Positioned(
              bottom: 100,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.green.shade800.withOpacity(0.95),
                  borderRadius: BorderRadius.circular(16),
                  border:
                      Border.all(color: Colors.green.shade400, width: 2),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.check_circle,
                        color: Colors.white, size: 36),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _recognizedName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          if (_recognizedRelation.isNotEmpty)
                            Text(
                              _recognizedRelation,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 16,
                              ),
                            ),
                          Text(
                            'Match: ${(_lastScore * 100).toStringAsFixed(1)}%',
                            style: const TextStyle(
                              color: Colors.white60,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Not recognized message
          if (_recognizedName.isEmpty &&
              _statusMessage == 'Face not recognized')
            Positioned(
              bottom: 100,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.red.shade800.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.person_off,
                        color: Colors.white, size: 32),
                    SizedBox(width: 12),
                    Text(
                      'Face not recognized',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),

      // Manual scan button
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isDetecting ? null : _detectAndRecognize,
        backgroundColor: Colors.purple,
        icon: _isDetecting
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2),
              )
            : const Icon(Icons.face_retouching_natural,
                color: Colors.white),
        label: Text(
          _isDetecting ? 'Scanning...' : 'Scan Now',
          style: const TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}