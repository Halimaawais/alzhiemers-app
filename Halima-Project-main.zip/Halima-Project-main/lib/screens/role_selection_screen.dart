// lib/screens/role_selection_screen.dart
import 'package:flutter/material.dart';
import 'dashboard_screen.dart';

class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select Role')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        const DashboardScreen(role: 'Patient')),
              ),
              child: Card(
                color: Colors.deepPurple.shade100,
                child: const Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(
                      child: Text('Patient',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold))),
                ),
              ),
            ),
            const SizedBox(height: 30),
            GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        const DashboardScreen(role: 'Caregiver')),
              ),
              child: Card(
                color: Colors.deepPurple.shade100,
                child: const Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(
                      child: Text('Caregiver',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold))),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
