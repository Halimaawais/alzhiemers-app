// lib/screens/caregiver_dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'login_screen.dart';
import 'enrolled_faces_screen.dart'; 

class CaregiverDashboardScreen extends StatefulWidget {
  const CaregiverDashboardScreen({super.key});

  @override
  State<CaregiverDashboardScreen> createState() => _CaregiverDashboardScreenState();
}

class _CaregiverDashboardScreenState extends State<CaregiverDashboardScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _uid = FirebaseAuth.instance.currentUser!.uid;

  // Add or Edit Reminder
  Future<void> _showReminderDialog({DocumentSnapshot? reminder}) async {
    final isEdit = reminder != null;
    final data = isEdit ? reminder.data() as Map<String, dynamic> : null;

    final TextEditingController titleController = 
        TextEditingController(text: data?['title'] ?? '');
    final TextEditingController descController = 
        TextEditingController(text: data?['description'] ?? '');
    
    String? selectedPatientUid = data?['patientId'];
    TimeOfDay? selectedTime;
    DateTime? selectedDate;

    // Parse existing time if editing
    if (isEdit && data?['scheduleTime'] != null) {
      final existingTime = (data!['scheduleTime'] as Timestamp).toDate();
      selectedDate = existingTime;
      selectedTime = TimeOfDay(hour: existingTime.hour, minute: existingTime.minute);
    }

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(isEdit ? "Edit Reminder" : "Add Reminder"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Patient Dropdown (disabled if editing)
                StreamBuilder<QuerySnapshot>(
                  stream: _firestore
                      .collection('users')
                      .where('role', isEqualTo: 'patient')
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      return const CircularProgressIndicator();
                    }
                    final patients = snapshot.data!.docs;
                    
                    if (patients.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(
                          'No patients found',
                          style: TextStyle(color: Colors.red),
                        ),
                      );
                    }
                    
                    return DropdownButtonFormField<String>(
                      initialValue: selectedPatientUid,
                      hint: const Text('Select Patient'),
                      items: patients.map((doc) {
                        final patientData = doc.data() as Map<String, dynamic>;
                        return DropdownMenuItem(
                          value: doc.id,
                          child: Row(
                            children: [
                              const Icon(Icons.person, size: 20),
                              const SizedBox(width: 8),
                              Text(patientData['name'] ?? patientData['email'] ?? 'Unknown'),
                            ],
                          ),
                        );
                      }).toList(),
                      onChanged: isEdit ? null : (val) {
                        setDialogState(() => selectedPatientUid = val);
                      },
                      decoration: InputDecoration(
                        labelText: 'Patient',
                        border: const OutlineInputBorder(),
                        prefixIcon: const Icon(Icons.person_outline),
                        enabled: !isEdit,
                      ),
                    );
                  },
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    labelText: "Title",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.title),
                    hintText: "e.g., Take Medicine",
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: descController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: "Description",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.description),
                    hintText: "e.g., Take blood pressure medicine with water",
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: selectedDate ?? DateTime.now(),
                            firstDate: DateTime.now().subtract(const Duration(days: 1)),
                            lastDate: DateTime.now().add(const Duration(days: 365)),
                          );
                          if (date != null) {
                            setDialogState(() => selectedDate = date);
                          }
                        },
                        icon: const Icon(Icons.calendar_today),
                        label: Text(
                          selectedDate != null
                              ? '${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}'
                              : 'Date',
                        ),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final time = await showTimePicker(
                            context: context,
                            initialTime: selectedTime ?? TimeOfDay.now(),
                          );
                          if (time != null) {
                            setDialogState(() => selectedTime = time);
                          }
                        },
                        icon: const Icon(Icons.access_time),
                        label: Text(
                          selectedTime != null
                              ? '${selectedTime!.hour.toString().padLeft(2, '0')}:${selectedTime!.minute.toString().padLeft(2, '0')}'
                              : 'Time',
                        ),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () async {
                if (selectedPatientUid != null &&
                    titleController.text.isNotEmpty &&
                    descController.text.isNotEmpty &&
                    selectedDate != null &&
                    selectedTime != null) {
                  
                  final scheduleDateTime = DateTime(
                    selectedDate!.year,
                    selectedDate!.month,
                    selectedDate!.day,
                    selectedTime!.hour,
                    selectedTime!.minute,
                  );

                  final reminderData = {
                    'patientId': selectedPatientUid,
                    'caregiverId': _uid,
                    'title': titleController.text.trim(),
                    'description': descController.text.trim(),
                    'scheduleTime': Timestamp.fromDate(scheduleDateTime),
                    'status': 'pending',
                    'voicePrompt': 'It is time for ${titleController.text.trim()}',
                  };

                  try {
                    if (isEdit) {
                      await reminder!.reference.update(reminderData);
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('✓ Reminder updated successfully'),
                          backgroundColor: Colors.green,
                        ),
                      );
                    } else {
                      reminderData['createdAt'] = FieldValue.serverTimestamp();
                      await _firestore.collection('reminders').add(reminderData);
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('✓ Reminder added successfully'),
                          backgroundColor: Colors.green,
                        ),
                      );
                    }
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Error: $e'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please fill all fields'),
                      backgroundColor: Colors.orange,
                    ),
                  );
                }
              },
              child: Text(isEdit ? "Update" : "Add"),
            ),
          ],
        ),
      ),
    );
  }

  // Delete Reminder
  Future<void> _deleteReminder(DocumentSnapshot reminder) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Reminder'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Are you sure you want to delete this reminder?'),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red.shade200),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    reminder['title'],
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    reminder['description'],
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    
    if (confirm == true) {
      await reminder.reference.delete();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✓ Reminder deleted'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Caregiver Dashboard", style: TextStyle(fontSize: 20)),
            Text("Manage Patient Reminders", style: TextStyle(fontSize: 12)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Logout'),
                  content: const Text('Are you sure you want to logout?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: const Text('Cancel'),
                    ),
                    ElevatedButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: const Text('Logout'),
                    ),
                  ],
                ),
              );
              if (confirm == true) {
                await FirebaseAuth.instance.signOut();
                if (!context.mounted) return;
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                  (route) => false,
                );
              }
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showReminderDialog(),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text("Add Reminder"),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() {});
          await Future.delayed(const Duration(milliseconds: 500));
        },
        child: StreamBuilder<QuerySnapshot>(
          stream: _firestore
              .collection('reminders')
              .where('caregiverId', isEqualTo: _uid)
              .orderBy('scheduleTime')
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            
            if (snapshot.hasError) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 64, color: Colors.red),
                    const SizedBox(height: 16),
                    Text('Error: ${snapshot.error}'),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () => setState(() {}),
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              );
            }

            final reminders = snapshot.data!.docs;

            if (reminders.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.event_note, size: 80, color: Colors.grey.shade400),
                    const SizedBox(height: 16),
                    Text(
                      "No reminders yet",
                      style: TextStyle(fontSize: 20, color: Colors.grey.shade600),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Tap the + button to add your first reminder",
                      style: TextStyle(color: Colors.grey.shade500),
                    ),
                  ],
                ),
              );
            }

            return ListView.builder(
              padding: const EdgeInsets.all(12.0),
              itemCount: reminders.length,
              itemBuilder: (context, index) {
                final reminder = reminders[index];
                final data = reminder.data() as Map<String, dynamic>;
                
                return FutureBuilder<DocumentSnapshot>(
                  future: _firestore.collection('users').doc(data['patientId']).get(),
                  builder: (context, patientSnapshot) {
                    String patientName = 'Loading...';
                    String? patientEmail;
                    
                    if (patientSnapshot.hasData && patientSnapshot.data!.exists) {
                      final patientData = patientSnapshot.data!.data() as Map<String, dynamic>;
                      patientName = patientData['name'] ?? 'Unknown';
                      patientEmail = patientData['email'];
                    }

                    final scheduleTime = data['scheduleTime'] != null
                        ? (data['scheduleTime'] as Timestamp).toDate()
                        : null;
                    
                    final timeString = scheduleTime != null
                        ? '${scheduleTime.hour.toString().padLeft(2, '0')}:${scheduleTime.minute.toString().padLeft(2, '0')}'
                        : 'Not set';
                    
                    final dateString = scheduleTime != null
                        ? '${scheduleTime.day}/${scheduleTime.month}/${scheduleTime.year}'
                        : '';

                    final isCompleted = data['status'] == 'completed';
                    
                    // Debug log
                    if (isCompleted) {
                      print('✅ Reminder "${data['title']}" is marked as completed');
                    }
                    
                    final isUpcoming = scheduleTime != null && scheduleTime.isAfter(DateTime.now()) && !isCompleted;
                    final isPast = scheduleTime != null && scheduleTime.isBefore(DateTime.now()) && !isCompleted;
                    final isToday = scheduleTime != null && 
                        scheduleTime.day == DateTime.now().day &&
                        scheduleTime.month == DateTime.now().month &&
                        scheduleTime.year == DateTime.now().year;

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12.0),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(
                          color: isCompleted 
                              ? Colors.green.shade200
                              : isToday && isUpcoming 
                                  ? Colors.teal.shade200 
                                  : Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: InkWell(
                        onTap: () => _showReminderDialog(reminder: reminder),
                        borderRadius: BorderRadius.circular(12),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  CircleAvatar(
                                    backgroundColor: isCompleted
                                        ? Colors.green.shade100
                                        : isUpcoming 
                                            ? Colors.teal.shade100 
                                            : Colors.grey.shade300,
                                    child: Icon(
                                      isCompleted ? Icons.check_circle : Icons.person,
                                      color: isCompleted ? Colors.green : isUpcoming ? Colors.teal : Colors.grey,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          patientName,
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                            color: Colors.grey.shade700,
                                          ),
                                        ),
                                        if (patientEmail != null)
                                          Text(
                                            patientEmail,
                                            style: TextStyle(
                                              fontSize: 11,
                                              color: Colors.grey.shade500,
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                  if (isCompleted)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: Colors.green.shade100,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.check_circle, size: 14, color: Colors.green.shade900),
                                          const SizedBox(width: 4),
                                          Text(
                                            'COMPLETED',
                                            style: TextStyle(
                                              color: Colors.green.shade900,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 10,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  else if (isToday && isUpcoming)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.teal.shade100,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        'TODAY',
                                        style: TextStyle(
                                          color: Colors.teal.shade900,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 10,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              const Divider(height: 24),
                              Text(
                                data['title'] ?? 'No title',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  decoration: isCompleted || isPast ? TextDecoration.lineThrough : null,
                                  color: isCompleted ? Colors.green.shade700 : isPast ? Colors.grey : Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                data['description'] ?? 'No description',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey.shade700,
                                ),
                              ),
                              const SizedBox(height: 16),
                              Row(
                                children: [
                                  Icon(
                                    Icons.access_time,
                                    size: 18,
                                    color: isCompleted ? Colors.green : isUpcoming ? Colors.teal : Colors.grey,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    timeString,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: isCompleted ? Colors.green : isUpcoming ? Colors.teal : Colors.grey,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Icon(
                                    Icons.calendar_today,
                                    size: 18,
                                    color: Colors.grey.shade600,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    dateString,
                                    style: TextStyle(color: Colors.grey.shade600),
                                  ),
                                  const Spacer(),
                                  if (isCompleted)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.green.shade50,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.check, size: 12, color: Colors.green.shade700),
                                          const SizedBox(width: 4),
                                          Text(
                                            'Done',
                                            style: TextStyle(
                                              color: Colors.green.shade700,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 10,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  else if (isPast)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.red.shade50,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        'PAST',
                                        style: TextStyle(
                                          color: Colors.red.shade700,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 10,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TextButton.icon(
                                    onPressed: () {
                                    Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => EnrolledFacesScreenLocal( // Add "Local"
                                                patientId: data['patientId'],
                                                patientName: patientName,
                                              ),
                                            ),
                                          );
                                    },
                                    icon: const Icon(Icons.face, size: 18),
                                    label: const Text('Faces'),
                                    style: TextButton.styleFrom(
                                      foregroundColor: Colors.blue,
                                    ),
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      TextButton.icon(
                                        onPressed: () => _showReminderDialog(reminder: reminder),
                                        icon: const Icon(Icons.edit, size: 18),
                                        label: const Text('Edit'),
                                        style: TextButton.styleFrom(
                                          foregroundColor: Colors.teal,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      TextButton.icon(
                                        onPressed: () => _deleteReminder(reminder),
                                        icon: const Icon(Icons.delete, size: 18),
                                        label: const Text('Delete'),
                                        style: TextButton.styleFrom(
                                          foregroundColor: Colors.red,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }
}