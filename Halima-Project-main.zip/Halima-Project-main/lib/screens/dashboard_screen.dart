// lib/screens/dashboard_screen.dart
import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  final String role;
  const DashboardScreen({super.key, required this.role});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('$role Dashboard')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: [
            Card(
              color: Colors.deepPurple.shade100,
              child: const Center(child: Text('Reminders')),
            ),
            Card(
              color: Colors.deepPurple.shade100,
              child: const Center(child: Text('Emergency Contacts')),
            ),
            Card(
              color: Colors.deepPurple.shade100,
              child: const Center(child: Text('Profile')),
            ),
            Card(
              color: Colors.deepPurple.shade100,
              child: const Center(child: Text('Settings')),
            ),
          ],
        ),
      ),
    );
  }
}
