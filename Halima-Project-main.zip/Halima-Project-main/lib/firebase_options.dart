import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: 'AIzaSyAGLbdy4LZhMIk3FfLBC6av4ZgcSYombbs',
      appId: '1:955091739172:android:ebdb08e9ba4ef350802eb1',
      messagingSenderId: '955091739172',
      projectId: 'alzheimermemoryapp-4d5a3',
    );
  }
}
