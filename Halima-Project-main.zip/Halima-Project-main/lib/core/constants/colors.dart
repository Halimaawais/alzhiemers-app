import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF6C63FF);
  static const secondary = Color(0xFF4A90E2);
  static const background = Color(0xFFF9F9FB);
  static const textDark = Color(0xFF1F2937);
  static const textLight = Color(0xFF6B7280);
}
