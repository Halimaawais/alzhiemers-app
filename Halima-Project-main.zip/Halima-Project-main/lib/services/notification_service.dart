import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    if (kIsWeb) return;

    tz.initializeTimeZones();

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(settings);

    // Permission request skipped for web/chrome compatibility
  }

  static Future<void> scheduleReminder({
    required int id,
    required String title,
    required String description,
    required DateTime scheduleTime,
  }) async {
    if (kIsWeb) return;

    final notifyTime = scheduleTime.subtract(const Duration(minutes: 1));

    if (notifyTime.isBefore(DateTime.now())) return;

    await _notifications.zonedSchedule(
      id,
      '⏰ Reminder: $title',
      description,
      tz.TZDateTime.from(notifyTime, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'reminders_channel',
          'Reminders',
          channelDescription: 'Patient reminder notifications',
          importance: Importance.max,
          priority: Priority.high,
          showWhen: true,
          enableVibration: true,
          playSound: true,
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );

    print('✅ Notification scheduled for $title at $notifyTime');
  }

  static Future<void> cancelReminder(int id) async {
    if (kIsWeb) return;
    await _notifications.cancel(id);
  }

  static Future<void> cancelAllReminders() async {
    if (kIsWeb) return;
    await _notifications.cancelAll();
  }

  static Future<void> scheduleAllPatientReminders() async {
    if (kIsWeb) return;

    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    await cancelAllReminders();

    final snapshot = await FirebaseFirestore.instance
        .collection('reminders')
        .where('patientId', isEqualTo: uid)
        .where('status', isEqualTo: 'pending')
        .get();

    for (final doc in snapshot.docs) {
      final data = doc.data();
      final scheduleTime = data['scheduleTime'] != null
          ? (data['scheduleTime'] as Timestamp).toDate()
          : null;

      if (scheduleTime == null || scheduleTime.isBefore(DateTime.now())) continue;

      final notifId = doc.id.hashCode.abs() % 100000;

      await scheduleReminder(
        id: notifId,
        title: data['title'] ?? 'Reminder',
        description: data['description'] ?? '',
        scheduleTime: scheduleTime,
      );
    }

    print('All reminders scheduled');
  }
}