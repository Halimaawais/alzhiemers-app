import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

class FaceEmbeddingService {
  static const int inputSize = 112;
  static const int embeddingSize = 192;

  Interpreter? _interpreter;
  bool _isLoaded = false;

  // Call this once when screen opens
  Future<void> loadModel() async {
    try {
      _interpreter = await Interpreter.fromAsset(
        'assets/models/mobilefacenet.tflite',
      );
      _isLoaded = true;
      print('✅ TFLite MobileFaceNet model loaded');
    } catch (e) {
      _isLoaded = false;
      print('❌ Failed to load TFLite model: $e');
    }
  }

  bool get isLoaded => _isLoaded;

  // Generate 192-dim embedding from a face image file.
  Future<List<double>> getEmbedding(File imageFile) async {
    final imageBytes = await imageFile.readAsBytes();
    final image = img.decodeImage(imageBytes);
    if (image == null) return List<double>.filled(embeddingSize, 0.0);
    return getEmbeddingFromImage(image);
  }

  // Generate L2-normalized 192-dim embedding from an in-memory image.
  // Use this with the face already cropped to its bounding box.
  Future<List<double>> getEmbeddingFromImage(img.Image image) async {
    if (!_isLoaded || _interpreter == null) {
      print('⚠️ Model not loaded, returning zeros');
      return List<double>.filled(embeddingSize, 0.0);
    }

    try {
      final resized = img.copyResize(
        image,
        width: inputSize,
        height: inputSize,
      );

      final input = Float32List(inputSize * inputSize * 3);
      int index = 0;
      for (int y = 0; y < inputSize; y++) {
        for (int x = 0; x < inputSize; x++) {
          final pixel = resized.getPixel(x, y);
          input[index++] = (pixel.r / 127.5) - 1.0;
          input[index++] = (pixel.g / 127.5) - 1.0;
          input[index++] = (pixel.b / 127.5) - 1.0;
        }
      }

      final output = List.generate(1, (_) => List.filled(embeddingSize, 0.0));
      _interpreter!.run(
        input.reshape([1, inputSize, inputSize, 3]),
        output,
      );

      return _l2Normalize(output[0]);
    } catch (e) {
      print('❌ Error generating embedding: $e');
      return List<double>.filled(embeddingSize, 0.0);
    }
  }

  static List<double> _l2Normalize(List<double> v) {
    double sumSq = 0.0;
    for (final x in v) {
      sumSq += x * x;
    }
    final norm = sqrt(sumSq);
    if (norm == 0.0) return v;
    return v.map((x) => x / norm).toList();
  }

  // Crop the detected face from `image` with 20% padding, clamped to bounds.
  // Returns null if the bounding box has no overlap with the image.
  static img.Image? cropFace(img.Image image, Face face) {
    final rect = face.boundingBox;
    final padding = rect.width * 0.2;
    final x = (rect.left - padding).toInt().clamp(0, image.width - 1);
    final y = (rect.top - padding).toInt().clamp(0, image.height - 1);
    final w = (rect.width + padding * 2).toInt().clamp(1, image.width - x);
    final h = (rect.height + padding * 2).toInt().clamp(1, image.height - y);
    return img.copyCrop(image, x: x, y: y, width: w, height: h);
  }

  void dispose() {
    _interpreter?.close();
  }
}
