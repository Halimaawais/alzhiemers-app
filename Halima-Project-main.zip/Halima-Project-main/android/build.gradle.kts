allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    afterEvaluate {
        extensions.findByName("android")?.let { ext ->
            try {
                val co = ext.javaClass.getMethod("getCompileOptions").invoke(ext)
                co.javaClass.getMethod("setSourceCompatibility", Any::class.java).invoke(co, JavaVersion.VERSION_17)
                co.javaClass.getMethod("setTargetCompatibility", Any::class.java).invoke(co, JavaVersion.VERSION_17)
            } catch (_: Exception) { }
        }
        tasks.withType(JavaCompile::class.java).configureEach {
            sourceCompatibility = "17"
            targetCompatibility = "17"
        }
        tasks.configureEach {
            if (this.javaClass.name.contains("KotlinCompile")) {
                try {
                    val ko = this.javaClass.getMethod("getKotlinOptions").invoke(this)
                    ko.javaClass.getMethod("setJvmTarget", String::class.java).invoke(ko, "17")
                } catch (_: Exception) { }
            }
        }
    }
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
